from django.apps import AppConfig


class alliancecraftsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'alliancecrafts'