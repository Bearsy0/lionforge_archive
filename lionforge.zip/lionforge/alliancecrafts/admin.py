from django.contrib import admin

from .models import CraftingRequest

admin.site.register(CraftingRequest)