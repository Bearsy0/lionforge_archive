from django.apps import AppConfig


class CrowcalcConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'crowcalc'
